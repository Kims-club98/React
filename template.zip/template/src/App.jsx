import './App.css';

const App = () => {
  return (
    <div className="App">
      Hello React!!!
    </div>
  );
}

export default App;
